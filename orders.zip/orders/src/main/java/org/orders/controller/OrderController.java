package org.orders.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller("Order")
public class OrderController {

	@RequestMapping("/")
	public String index() {
		System.out.println("aqui estoy!!!!!!");
		return "index";
	}
	
	@RequestMapping(value="/pedidos/list", method=RequestMethod.GET)
	public String listOrder() {
		return "order/list";
	}
	
	@RequestMapping(value="/pedidos/new", method=RequestMethod.GET)
	public String newOrder() {
		return "order/form";
	}	
	
	@RequestMapping(value="/pedidos/create", method=RequestMethod.POST)
	public String createOrder() {
		return "order/form";
	}
	
	@RequestMapping(value="/pedidos/edit", method=RequestMethod.GET)
	public String editOrder() {
		return "order/form";
	}
	
	@RequestMapping(value="/pedidos/update", method=RequestMethod.POST)
	public String updateOrder() {
		return "order/form";
	}
}
